//
//  LevelPlayMediaView.h
//  IronSource
//
//  Created by Hadar Pur on 04/06/2023.
//  Copyright © 2023 IronSource. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LevelPlayMediaView : UIView

@end
