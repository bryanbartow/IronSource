//
//  ISMediationGlobalDataWriterFacade.h
//  IronSource
//
//  Created by noy.fridman on 21/03/2024.
//

#import <Foundation/Foundation.h>

@interface ISMediationGlobalDataWriterFacade : NSObject
- (void)setGoogleWaterMark:(NSString *)waterMark;

@end
